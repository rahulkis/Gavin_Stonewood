/**
 * Porto Header Builder blocks
 */

import './blocks/logo';
import './blocks/menu';
import './blocks/switcher';
import './blocks/search_form';
import './blocks/minicart';
import './blocks/social';
import './blocks/menu_icon';
import './blocks/divider';
import './blocks/myaccount';
import './blocks/wishlist';
import './blocks/compare';